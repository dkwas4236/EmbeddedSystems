

/**
 * main.c
 * Author: Darion
 * ID: 3122890
 */
#include "toogle_button.h"

int main(void)
{
    demoToogle();
    PRCMSleep();
	return 0;
}
